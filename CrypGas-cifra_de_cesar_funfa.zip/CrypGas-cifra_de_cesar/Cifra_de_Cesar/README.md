# CrypGas
O CrypGas é um projeto desenvolvido na matéria de Laboratório de Processadores (PCS3732) com foco em desenvolver algoritmos de encriptografia em C  para serem executados em uma Raspberry Pi 2.
