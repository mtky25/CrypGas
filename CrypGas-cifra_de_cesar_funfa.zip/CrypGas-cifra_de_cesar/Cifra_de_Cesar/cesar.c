#include "cesar.h"

char cifra_cesar(char c, int chave){
    if (c >= 'A' && c <= 'Z')
        return ((c - 'A' + chave + 26) % 26) + 'A';
    else if (c >= 'a' && c <= 'z')
        return ((c - 'a' + chave + 26) % 26) + 'a';
    else return c;
}

void apply_cifra(char *str, int chave){
    for (int i = 0; str[i] != '\0'; i++)
        str[i] = cifra_cesar(str[i], chave);
}