#ifndef CESAR_H
#define CESAR_H

char cifra_cesar(char c, int chave);
void apply_cifra(char *str, int chave);

#endif 

