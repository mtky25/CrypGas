#include "cesar.h"
#include "uart.h"

void main(void) {
    uart_init();

    char buffer[100];
    int i = 0;

    uart_puts("Pronto para receber:\r\n");

    while (1) {
        char c = uart_get();
        uart_send(c); 
        uart_puts("Entra no while:\n");
        uart_puts("Recebido: ");
        uart_puts(" (ASCII ");
        uart_send('0' + (c / 100) % 10);
        uart_send('0' + (c / 10) % 10);
        uart_send('0' + (c % 10));
        uart_puts(")\r\n");
        if (c == '\r' || c == '\n') {
                break;
        }

        if (i < 99) {
            buffer[i++] = c;
        }
    }

    buffer[i] = '\0';
    uart_puts("Sai no while:\n");
    apply_cifra(buffer, 3); 

    uart_puts("\r\nResposta:\r\n");
    uart_puts(buffer);
    uart_send('\r');
    uart_send('\n');

    while (1);
}
